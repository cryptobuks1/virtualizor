<?php

//////////////////////////////////////////////////////////////
//===========================================================
// edittransaction_theme.php
//===========================================================
// SOFTACULOUS VIRTUALIZOR
// Version : 1.0
// Inspired by the DESIRE to be the BEST OF ALL
// ----------------------------------------------------------
// Started by: Alons
// Date:       8th Mar 2010
// Time:       23:00 hrs
// Site:       https://www.virtualizor.com/ (SOFTACULOUS VIRTUALIZOR)
// ----------------------------------------------------------
// Please Read the Terms of use at https://www.virtualizor.com
// ----------------------------------------------------------
//===========================================================
// (c)Softaculous Ltd.
//===========================================================
//////////////////////////////////////////////////////////////

if(!defined('VIRTUALIZOR')){

	die('Hacking Attempt');

}

function edittransaction_theme(){

global $theme, $globals, $kernel, $user, $l, $error, $done, $users, $tranx;

softheader($l['<title>']);

echo '
<div class="bg">
<center class="tit"><i class="icon icon-billing icon-head"></i>&nbsp; '.$l['_head'].'</center>';

error_handle($error);

if(!empty($done)){
	echo '<div class="notice"><img src="'.$theme['images'].'notice.gif" /> &nbsp; '.$l['done'].'</div>';
}

echo '<div id="form-container">
<form accept-charset="'.$globals['charset'].'" name="edittransaction" method="post" action="" class="form-horizontal">

	<div class="row">
		<div class="col-sm-5">
			<label class="control-label">'.$l['select_user'].'</label>
			<span class="help-block">'.$l['exp_select_user'].'</span>
		</div>
		<div class="col-sm-6">
			<select class="form-control" name="uid" id="uid">
			<option value="0" '.(POSTval('uid') == 0 ? 'selected="selected"' : '').'>'.$l['select_user'].'</option>';	
			foreach($users as $k => $v){		 
				echo '<option value="'.$k.'" '.POSTselect('uid', $k, $k == $tranx['uid']).'>'.$v['email'].'</option>';
			}
	
		echo '</select>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-5">
			<label class="control-label">'.$l['date'].'</label>
			<span class="help-block">'.$l['exp_date'].'</span>
		</div>
		<div class="col-sm-4">
			<input type="text" class="form-control" placeholder="DD/MM/YYYY" name="date" id="date" size="30" value="'.POSTval('date', datetime($tranx['date'])).'" />
		</div>
		<div class="col-sm-2">
			<input type="button" class="btn" onclick="$_(\'date\').value=\''.datify(time(), 0, 1, 'd/m/Y').'\'" value="'.$l['current_day'].'" />
		</div>
	</div>
	<div class="row">
		<div class="col-sm-5">
			<label class="control-label">'.$l['trtime'].'</label>
			<span class="help-block">'.$l['exp_trtime'].'</span>
		</div>
		<div class="col-sm-4">
			<input type="text" class="form-control" placeholder="HH:MM:SS" name="time" id="trtime" size="30" value="'.POSTval('time', datify($tranx['unixtime'], 0, 1, 'h:i:s')).'" />
		</div>
		<div class="col-sm-2">
			<input type="button" class="btn" onclick="$_(\'trtime\').value=\''.datify(time(), 0, 1, 'h:i:s').'\'" value="'.$l['current_time'].'" />
		</div>
		
	</div>
	<div class="row">
		<div class="col-sm-5">
			<label class="control-label">'.$l['gateway'].'</label>
			<span class="help-block">'.$l['exp_gateway'].'</span>
		</div>
		<div class="col-sm-6">
			<input type="text" class="form-control" name="gateway" id="gateway" value="'.POSTval('gateway', $tranx['gateway']).'" />
		</div>
	</div>
	<div class="row">
		<div class="col-sm-5">
			<label class="control-label">'.$l['token'].'</label>
			<span class="help-block">'.$l['exp_token'].'</span>
		</div>
		<div class="col-sm-6">
			<input type="text" class="form-control" name="token" id="token" value="'.POSTval('token', $tranx['token']).'" />
		</div>
	</div>
	<div class="row">
		<div class="col-sm-5">
			<label class="control-label">'.$l['amt'].'</label>
			<span class="help-block">'.$l['exp_amt'].'</span>
		</div>
		<div class="col-sm-6">
			<input type="text" class="form-control" name="amt" id="amt" value="'.POSTval('amt', $tranx['amt']).'" onchange="calc_net()" />
		</div>
	</div>
	<div class="row">
		<div class="col-sm-5">
			<label class="control-label">'.$l['fees'].'</label>
			<span class="help-block">'.$l['exp_fees'].'</span>
		</div>
		<div class="col-sm-6">
			<input type="text" class="form-control" name="fees" id="fees" value="'.POSTval('fees', $tranx['fees']).'" onchange="calc_net()" />
		</div>
	</div>
	<div class="row">
		<div class="col-sm-5">
			<label class="control-label">'.$l['net'].'</label>
			<span class="help-block">'.$l['exp_net'].'</span>
		</div>
		<div class="col-sm-6">
			<input type="text" disabled="disabled" class="form-control" name="net" id="net" value="" />
		</div>
	</div>
		
</div>

<br /><br />
<center><input type="submit" class="btn" name="edittransaction" value="'.$l['submit'].'"></center>

</form>

<script language="javascript" type="text/javascript">
function calc_net(){
	var amt = parseFloat($_("amt").value);
	var fees = parseFloat($_("fees").value);
	if(amt > 0){
		$_("net").value = amt - (fees > 0 ? fees : 0);
	}
};

calc_net();
</script>

</div>
</div>
';


softfooter();

}
